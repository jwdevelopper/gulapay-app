# GulaPay — Assets pra Flutter

Pacote com a imagem de fundo, o mascote e o widget de bolhas animadas para integrar ao seu app Flutter.

## 📦 O que tem aqui

```
flutter_export/
├── assets/
│   ├── login_bg.jpg              # 1080x2400 (1x base)
│   ├── logo_mascot.png           # 512x512  (1x)
│   ├── 2.0x/
│   │   └── logo_mascot.png       # 1024x1024 (2x)
│   └── 3.0x/
│       └── logo_mascot.png       # 1536x1536 (3x)
└── lib/
    └── animated_login_background.dart   # widget c/ bolhas animadas
```

## 1. Configurar o `pubspec.yaml`

```yaml
flutter:
  uses-material-design: true
  assets:
    - assets/login_bg.jpg
    - assets/logo_mascot.png
```

> O Flutter pega automaticamente as variantes `2.0x/` e `3.0x/` se elas
> estiverem na mesma pasta do asset base. Não precisa listar as variantes.

## 2. Copiar os arquivos

Mova:
- `flutter_export/assets/*` → `<seu_projeto>/assets/`
- `flutter_export/lib/animated_login_background.dart` → `<seu_projeto>/lib/widgets/animated_login_background.dart`

## 3. Usar na tela de login

```dart
import 'package:flutter/material.dart';
import 'widgets/animated_login_background.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Fundo + bolhas animadas
          const AnimatedLoginBackground(),

          // Conteúdo (mascote, formulário, etc.)
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const SizedBox(height: 24),
                  Image.asset(
                    'assets/logo_mascot.png',
                    width: 132,
                    height: 132,
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'GulaPay',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFFFFF5DC),
                      letterSpacing: -0.6,
                    ),
                  ),
                  // ... resto do form ...
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
```

## 4. Customizar as bolhas

```dart
const AnimatedLoginBackground(bubbleCount: 30); // mais densidade
```

Para mudar tamanhos, drift ou cores, edite `_BubblesPainter` em
`animated_login_background.dart`. As cores das bolhas estão no
`RadialGradient` (creme/dourado pra combinar com o fundo terracota).

## 5. Mascote — animação opcional

Se quiser o efeito "bob" suave que o protótipo tem na web, envolva a
imagem assim:

```dart
class BouncyMascot extends StatefulWidget {
  const BouncyMascot({super.key});
  @override State<BouncyMascot> createState() => _BouncyMascotState();
}

class _BouncyMascotState extends State<BouncyMascot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 3500),
  )..repeat(reverse: true);

  @override void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, child) {
        final t = Curves.easeInOut.transform(_c.value);
        return Transform.translate(
          offset: Offset(0, -6 * t),
          child: Transform.rotate(
            angle: -0.018 + 0.053 * t, // -1° → +2°
            child: child,
          ),
        );
      },
      child: Image.asset('assets/logo_mascot.png', width: 132, height: 132),
    );
  }
}
```

## Cores da paleta (pra reaproveitar nos seus widgets)

| Token             | Hex        |
|-------------------|------------|
| Cream             | `#FFF5DC`  |
| Cream dim         | `#F5ECD0`  |
| Honey accent      | `#FFD278`  |
| Orange CTA top    | `#FF8A3D`  |
| Orange CTA bottom | `#E85D1C`  |
| Brick deep        | `#5C1F0E`  |
| Coffee text       | `#3D1208`  |
