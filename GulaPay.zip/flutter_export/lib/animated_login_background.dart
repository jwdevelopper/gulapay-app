// lib/widgets/animated_login_background.dart
//
// Animated login background for GulaPay
// - Uses assets/login_bg.jpg as the static art
// - Overlays soda-bubbles rising from bottom with random sizes/drift
//
// Usage:
//   Stack(
//     children: [
//       const AnimatedLoginBackground(),
//       // ... your form content above ...
//     ],
//   )

import 'dart:math';
import 'package:flutter/material.dart';

class AnimatedLoginBackground extends StatefulWidget {
  final int bubbleCount;
  const AnimatedLoginBackground({super.key, this.bubbleCount = 22});

  @override
  State<AnimatedLoginBackground> createState() =>
      _AnimatedLoginBackgroundState();
}

class _AnimatedLoginBackgroundState extends State<AnimatedLoginBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctl;
  late final List<_Bubble> _bubbles;
  final Random _rng = Random();

  @override
  void initState() {
    super.initState();
    _ctl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 60),
    )..repeat();

    _bubbles = List.generate(widget.bubbleCount, (i) {
      return _Bubble(
        size: 8 + _rng.nextDouble() * 42,
        leftFrac: _rng.nextDouble(),
        delay: _rng.nextDouble(),
        duration: 7 + _rng.nextDouble() * 10, // seconds
        driftPx: (_rng.nextDouble() - 0.5) * 80,
        opacity: 0.18 + _rng.nextDouble() * 0.4,
      );
    });
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Static background art
        Image.asset(
          'assets/login_bg.jpg',
          fit: BoxFit.cover,
        ),

        // Dark gradient overlay for legibility
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0x0D32120A),
                Color(0x4032120A),
                Color(0xB3280C04),
              ],
              stops: [0.0, 0.45, 1.0],
            ),
          ),
        ),

        // Soda bubbles
        AnimatedBuilder(
          animation: _ctl,
          builder: (context, _) {
            return CustomPaint(
              painter: _BubblesPainter(
                bubbles: _bubbles,
                t: _ctl.value * 60, // seconds elapsed in cycle
              ),
              size: Size.infinite,
            );
          },
        ),
      ],
    );
  }
}

class _Bubble {
  final double size;
  final double leftFrac;
  final double delay;     // 0..1, fraction of duration to offset start
  final double duration;  // seconds for one rise
  final double driftPx;   // horizontal drift in px
  final double opacity;

  _Bubble({
    required this.size,
    required this.leftFrac,
    required this.delay,
    required this.duration,
    required this.driftPx,
    required this.opacity,
  });
}

class _BubblesPainter extends CustomPainter {
  final List<_Bubble> bubbles;
  final double t;

  _BubblesPainter({required this.bubbles, required this.t});

  @override
  void paint(Canvas canvas, Size size) {
    for (final b in bubbles) {
      final localT = ((t / b.duration) + b.delay) % 1.0;
      final progress = localT; // 0..1

      // Vertical position: from bottom (off-screen) to top (off-screen)
      final startY = size.height + 60;
      final endY = -size.height * 0.1;
      final y = startY + (endY - startY) * progress;

      // Horizontal drift
      final driftCurve = _ease(progress);
      final x = b.leftFrac * size.width + b.driftPx * driftCurve;

      // Opacity envelope (fade in 0..0.12, hold, fade out 0.85..1)
      double alpha;
      if (progress < 0.12) {
        alpha = (progress / 0.12) * b.opacity;
      } else if (progress > 0.85) {
        alpha = ((1 - progress) / 0.15) * b.opacity;
      } else {
        alpha = b.opacity;
      }
      alpha = alpha.clamp(0.0, 1.0);

      // Scale pulse (0.6 -> 1.05 -> 0.4)
      final scale = 0.6 +
          0.45 * sin(progress * pi).clamp(0.0, 1.0);
      final r = (b.size / 2) * scale;

      // Bubble body — radial gradient (cream -> warm -> transparent)
      final rect = Rect.fromCircle(center: Offset(x, y), radius: r);
      final gradient = RadialGradient(
        center: const Alignment(-0.4, -0.4),
        colors: [
          Color.fromRGBO(255, 245, 220, (0.95 * alpha).clamp(0, 1)),
          Color.fromRGBO(255, 220, 160, (0.55 * alpha).clamp(0, 1)),
          Color.fromRGBO(255, 200, 120, (0.15 * alpha).clamp(0, 1)),
          const Color(0x00000000),
        ],
        stops: const [0.0, 0.35, 0.7, 1.0],
      );

      final paint = Paint()..shader = gradient.createShader(rect);
      canvas.drawCircle(Offset(x, y), r, paint);

      // White shine highlight
      final shinePaint = Paint()
        ..color = Color.fromRGBO(255, 255, 255, (0.85 * alpha).clamp(0, 1));
      canvas.drawCircle(
        Offset(x - r * 0.28, y - r * 0.28),
        r * 0.18,
        shinePaint,
      );
    }
  }

  double _ease(double t) {
    // simple ease-in-out
    return t < 0.5 ? 2 * t * t : 1 - pow(-2 * t + 2, 2) / 2;
  }

  @override
  bool shouldRepaint(_BubblesPainter old) => old.t != t;
}
